python main.py --model_type ngram --preprocess 0 --part 2
python main.py --model_type ngram --preprocess 1 --part 2
python main.py --model_type BERT --preprocess 0 --part 2
python main.py --model_type BERT --preprocess 1 --part 2